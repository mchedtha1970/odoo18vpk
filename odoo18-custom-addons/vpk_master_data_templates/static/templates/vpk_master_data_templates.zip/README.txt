VPK Templates

vpk_opening_equipment_asset.xlsx = ยกยอด Equipment + Asset Profile/Card
vpk_master_equipment.xlsx = Equipment Category + Equipment อย่างเดียว
ลิงก์ด้วยคอลัมน์ asset_number → account.asset.number
